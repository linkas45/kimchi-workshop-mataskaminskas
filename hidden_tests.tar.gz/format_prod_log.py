#!/usr/bin/env python3
"""Format hidden-suite pytest results as a Production Log.

Reads a pytest junit XML report from the hidden suite and emits a
markdown PR comment that reads like an incident channel going sideways,
not a test summary. Deterministic; zero external calls at runtime.

Scene: you are the new junior engineer on the team. A senior engineer
shipped task-api last Friday. It's Monday morning and production is
misbehaving. The office Slack is lighting up. Escalation depends on
how many stages survive.

Drama levels (driven by failure count):
  calm      0 fails   deploy is green, office is quiet
  tense     1-2 fails someone notices something off
  incident  3-5 fails the senior engineer gets pinged
  disaster  6+ fails  CTO breaks in, "This is fine."

GIFs are hardcoded verified-live links (curl-checked) so the comment
never depends on an external API at render time.
"""
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict

STAGE_ORDER = ["deployment", "validation", "traffic", "export",
               "rate_limit", "gc", "sync", "timestamps", "cache"]

STAGE_VMAP = {1: "deployment", 2: "validation", 3: "traffic",
              4: "export", 5: "rate_limit", 6: "gc",
              7: "sync", 8: "timestamps", 9: "cache"}

GIFS = {
    "panic": "https://media.giphy.com/media/NTUR7XFezw1VQwxpS7/giphy.gif",
    "watching": "https://media.giphy.com/media/oesCisZXmAJwQaGSYE/giphy.gif",
    "die": "https://media.giphy.com/media/l2JhhKtSuFQlz8EeI/giphy.gif",
    "fine": "https://media.giphy.com/media/3o6wriBanZ32aZRlUc/giphy.gif",
    "explode": "https://media.giphy.com/media/QMHoU866sK5Ss/giphy.gif",
}

# (label, pass_line, fail_line, fail_office_line, hint, gif_key)
# Neutral role labels only, no personal names. Same escalation arc.
# Hints are scoped precise enough that a typical agent can read the
# failing test, look at the hint, and land one fix per iteration.
STAGES = {
    "deployment": (
        "Deployment",
        "Deployment initiated. Containers warm, hands dry.",
        "Deployment initiated. Then the pager went off.",
        "The on-call (Slack): \"I tested it locally, it worked on my machine.\" Their machine. Classic.",
        "the app reads SECRET_KEY and DEBUG from env names `TASK_API_SECRET` and `TASK_API_DEBUG` - the seed hardcoded both",
        "panic",
    ),
    "validation": (
        "Validation",
        "Validation layer up, malformed payloads bounce off clean.",
        "The API is 500ing on trivially bad input.",
        "Support: \"Users are pasting emojis into the title field and the whole request dies.\"",
        "missing title, wrong-shaped priority (string/bool/int out of range), and any non-JSON body - all must be 400 bad_request, not 500",
        "watching",
    ),
    "traffic": (
        "Traffic shaping",
        "Pagination and filters behave, responses stay bounded.",
        "/tasks returned the whole table. The whole table.",
        "DevOps: \"Why is the response body 40MB.\" Nobody answers.",
        "the list response contract is a paginated dict, not a bare array: `{tasks: [...], total: N, limit: N, offset: N}` - default limit=20, accept query params limit/offset",
        "die",
    ),
    "export": (
        "Bulk export",
        "CSV export reflects the current state of the world.",
        "Finance downloaded the export and half their tasks vanished.",
        "Finance: \"We exported after cleaning up and the deleted tasks are still in the CSV.\"",
        "CSV header column order is: id, title, status, priority, created_at, completed_at, updated_at - deletes must drop the row, no truncation",
        "watching",
    ),
    "rate_limit": (
        "Rate limiting",
        "Rate limiter holds the line at sustained load.",
        "Load test hit 50 rps and the service ate every single request. There is no limiter.",
        "The on-call: \"I wrote a limiter.\" Everyone looks at the code. It rebuilds itself per request.",
        "the limiter is recreated per request - build one shared SlidingWindowLimiter instance OUTSIDE before_request, return 429 with Retry-After header",
        "fine",
    ),
    "gc": (
        "Garbage collection",
        "GC respects last-activity and leaves live tasks alone.",
        "Tasks people were actively editing started disappearing.",
        "Support ticket: \"My task is GONE. I was editing it five minutes ago.\" Reproducible. Ouch.",
        "GC looks at created_at; should look at the LATEST of created_at/updated_at - AND must never reap tasks whose status is completed, regardless of age",
        "explode",
    ),
    "sync": (
        "Sync conflicts",
        "Sync merges resolve last-writer-wins with a sane tie-break.",
        "Two regions synced and the newer edit lost to the older one.",
        "The EU office edited a task. US overwrote it with stale data. EU is Not Pleased.",
        "later updated_at should win, ties keep local",
        "watching",
    ),
    "timestamps": (
        "Time hygiene",
        "Timestamps are UTC-aware and round-trip cleanly.",
        "Time comparisons are throwing TypeErrors in logs.",
        "3:14 AM the logs fill with naive-vs-aware datetime errors. The on-call does not sleep.",
        "datetime.utcnow() is deprecated, use datetime.now(timezone.utc)",
        "explode",
    ),
    "cache": (
        "Cache invalidation",
        "Cache invalidates on every write.",
        "Deleted a task. Refreshed. Still there. Refreshed. Still there.",
        "Everyone starts hard-refreshing their browsers like it's 2009.",
        "writes need to invalidate the list cache",
        "fine",
    ),
}

OPENERS = {
    "calm": (
        "",
        [
            "Deploy is green, dashboards are quiet, Accounting just asked me what the fuss was about. No fires.",
            "The on-call can take the rest of the day off. They've earned it.",
            "You shipped clean. Sit back, drink the coffee.",
        ],
    ),
    "tense": (
        "_heads up: a few rough edges in prod_",
        [
            "Hey — service is up, but production noticed a few things. Small fires only so far.",
            "The on-call is saying \"it's probably user error\" in the voice people use when they're not quite sure.",
            "Here's what's actually happening:",
        ],
    ),
    "incident": (
        "_task-api's been paged again, looped you in_",
        [
            "Production is angry. The incident channel's been spinning for a while now.",
            "The on-call joined the call forty seconds late saying \"okay so, funny story.\"",
            "The floor has that specific silence where everyone's in the same channel and nobody's typing.",
            "Production report, straight from the service:",
        ],
    ),
    "disaster": (
        "_not what shipping looks like_",
        [
            "The CTO's in the thread. The CTO never joins the thread.",
            "Priority list, verbatim: \"1. Why is this on fire. 2. Who deployed this. 3. Fix it.\"",
            "Office is tense. Support is holding three refresh loops.",
            "![This is fine.](" + GIFS["fine"] + ")",
            "Here is the damage report:",
        ],
    ),
}

VERDICTS = {
    "calm": "Ship it. Nobody gets paged. This is the good Monday.",
    "tense": "Fixable before lunch if you move. Do not let it become a meeting.",
    "incident": "Hotfix now, post-mortem Thursday. The on-call owes the team coffee.",
    "disaster": "Rollback or fix forward, pick one fast. The CTO is already drafting the retro doc.",
}


def parse_junit(path):
    tree = ET.parse(path)
    root = tree.getroot()
    by_stage = defaultdict(list)
    for suite in root.iter("testsuite"):
        for case in suite.iter("testcase"):
            name = case.get("name", "")
            m = re.match(r"test_v(\d+)_", name)
            if not m:
                continue
            v = int(m.group(1))
            stage = STAGE_VMAP.get(v)
            if not stage:
                continue
            failed = any(child.tag in ("failure", "error") for child in case)
            msg = ""
            if failed:
                for child in case:
                    if child.tag in ("failure", "error"):
                        msg = (child.get("message") or child.text or "")
                        msg = msg.strip().splitlines()[0] if msg else ""
                        break
            by_stage[stage].append((failed, msg))
    return by_stage


def drama_level(total_fails):
    if total_fails == 0:
        return "calm"
    if total_fails <= 2:
        return "tense"
    if total_fails <= 5:
        return "incident"
    return "disaster"


def count_failed_stages(by_stage):
    fails = 0
    for stage_key in STAGE_ORDER:
        checks = by_stage.get(stage_key, [])
        if checks and any(f for f, _ in checks):
            fails += 1
    return fails


def render(by_stage, junit_file):
    total_pass = sum(1 for tests in by_stage.values() for t in tests if not t[0])
    total = sum(len(tests) for tests in by_stage.values())
    failed_stages = count_failed_stages(by_stage)
    mood = drama_level(failed_stages)
    title, opener = OPENERS[mood]

    lines = []
    if title:
        lines.append(title)
        lines.append("")
    for line in opener:
        lines.append(line)
        lines.append("")

    lines.append("")

    for stage_key in STAGE_ORDER:
        if stage_key not in by_stage:
            continue
        label, pass_line, fail_line, office_line, hint, gif_key = STAGES[stage_key]
        checks = by_stage[stage_key]
        passed = sum(1 for f, _ in checks if not f)
        n = len(checks)
        stage_ok = passed == n

        if stage_ok:
            lines.append(f"✅ **{label}** — {pass_line}")
        else:
            lines.append(f"❌ **{label}** — {fail_line}")
            lines.append(f"   {office_line}")
            lines.append(f"   {hint}")
        lines.append("")

    lines.append("---")
    lines.append(f"**{total_pass}/{total} checks green.** {VERDICTS[mood]}")
    if mood != "calm":
        lines.append("")
        lines.append("Alex.")
    return "\n".join(lines), total_pass, total


def main():
    if len(sys.argv) < 2:
        print("usage: format_prod_log.py <junit.xml> [out.md]", file=sys.stderr)
        sys.exit(1)
    junit_file = sys.argv[1]
    by_stage = parse_junit(junit_file)
    md, passed, total = render(by_stage, junit_file)
    if len(sys.argv) >= 3:
        with open(sys.argv[2], "w") as f:
            f.write(md)
    print(md)
    print(f"::set-output name=passed::{passed}", file=sys.stderr)
    print(f"::set-output name=total::{total}", file=sys.stderr)


if __name__ == "__main__":
    main()
